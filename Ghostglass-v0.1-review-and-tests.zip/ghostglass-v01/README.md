# Ghostglass v0.1 — court review and statistical reference

Status: local synthetic software reference; no detector validation or discovery claim.

## What advanced

The CHRONOVISOR–N/S Ghostglass concept is split into two independently testable branches:

1. Hardware: an optical calibration and, later, controlled neutron-tagging testbed. Gadolinium-water inverse-beta detection is established physics; this project does not establish new neutrino physics. Begin with optical timing, light collection, dark counts and stability. Neutron efficiency/capture-time studies require an appropriately equipped laboratory, independent predictions and measured accidental backgrounds. Tank dimensions and source goals remain unfrozen.
2. Software: a bounded on/off-count statistical reference with fixed trial allocation, explicit inconclusive states, duplicate handling, retractions and deterministic audit replay. It is not yet an observatory adapter or full multimessenger analysis.

Remove unsupported poster readouts such as “2.6 ± 0.4 TeV” and “98.7% quality.” Directional reconstruction and flavor-independent detection are not demonstrated. The image remains a concept visualization.

## Statistical correction

Treating an estimated background as exactly known can yield extremely misleading significance, especially when an off-window happens to contain zero events. Under independent Poisson on/off counts with the same underlying rate and known exposure ratio r, conditioning on their sum eliminates that unknown rate:

    N_on | (N_on + N_off) ~ Binomial(N_on + N_off, 1/(1+r))

Use the exact upper-tail probability. A candidate requires p <= alpha/m, where m includes every reserved trial, including missing, inconclusive and retracted trials. Bonferroni allows dependent trials provided each marginal p-value is valid. The on/off conditional model still requires its own assumptions. This implementation does not validate those assumptions from data.

The manifest currently binds IDs only. A real adapter must bind window definitions, sources, exposure, energy/direction cuts and analysis versions before examining outcomes. An indefinitely operating service needs a declared sequential error budget; repeatedly restarting a fixed family does not preserve a lifetime guarantee.

## Executed experiment

Fixed before this run: seed 20261019, 20,000 families, 100 windows per family, alpha=1%, on-background mean=0.2, off exposure=10 times on exposure. Counts are synthetic. Separate seeds are used for injections and stress cases; this is not a human-blinded study or external preregistration.

| Case | Families with at least one false alert | Rate |
|---|---:|---:|
| Exactly known background, no multiple-testing correction | 2,121 / 20,000 | 10.605% |
| Exactly known background, Bonferroni | 118 / 20,000 | 0.590% |
| Estimated background naively substituted into Poisson, Bonferroni | 18,339 / 20,000 | 91.695% |
| Conditional on/off binomial, Bonferroni | 21 / 20,000 | 0.105% |
| Same conditional method, unflagged fivefold on-only background shift | 6,489 / 20,000 | 32.445% |
| Same conditional method, independent overdispersed on/off counts, variance=3×mean | 10,185 / 20,000 | 50.925% |

The corrected null rate has a 95% Clopper–Pearson interval of approximately 0.065–0.160%. It is conservative relative to the 1% target. At a single synthetic signal mean of six additional events, injected-window detection was 13,125/20,000 = 65.625%; this is one operating point, not a detector sensitivity curve. No gain over established statistical methods is claimed.

One perfectly dependent trial construction (100 duplicates of one valid count pair) had zero false-alert families. This is a limited stress example, not validation of arbitrary overlapping-window implementations.

Drift and overdispersion are assumption failures, not repaired by multiple-testing correction. On/off counts alone cannot distinguish every background rise from a signal. Therefore the general robustness gate remains OPEN.

## Protocol tests and limitations

13 focused unit tests passed; see test-record.txt. They cover missing/malformed counts, health flags, fixed trial IDs, duplicates, forbidden revisions, retraction, replay mismatch and input detachment. Missing evidence returns INCONCLUSIVE rather than a zero-event observation. Health flags are trusted inputs; their truth is not established by this code. Quality decisions must not be chosen after observing candidate signal counts.

The ledger is an in-memory audit reference. SHA-256 chaining and replay comparison do not establish authentication, durable storage, rollback protection, immutable evidence or resistance to an attacker rewriting the entire record. No real device, alert stream, clock authority or protected store is connected.

## Next gate (proposal; not executed)

Before another evaluation, freeze a measured-background study with held-out data, matched exposures, predeclared strata, complete selection rules and failure criteria. Any time-slide null must justify exchangeability and preserve relevant correlations. Failed timing/exposure/background checks must yield INCONCLUSIVE without removing trials from the budget. Tests chosen after inspecting signal counts require explicit selection accounting.

Proposed numerical acceptance: across 20,000 independent held-out null search families, require the one-sided 95% exact binomial upper bound on family-wise false alerts to be <=1% in EACH predeclared operating regime. Reusing a finite background dataset may prevent independence; justify an appropriate uncertainty method before applying this criterion. Do not report a pass by silently excluding difficult regimes. Also report inconclusive fractions, exposure coverage and a signal-strength power curve; freeze minimum operational coverage and power goals after selecting the actual scientific target, before evaluating held-out data. Until those goals are fixed and measured evidence exists, this is not a deployable acceptance plan.

Hardware progress needs a separate source/event/background budget and measured calibration evidence. An illustrative yield of 3.34 events from 100 metric tons of water, fluence 1e11/cm², spectrum-averaged effective cross-section 1e-41 cm² and efficiency 0.5 is arithmetic only, not a source prediction or feasibility demonstration.

## Court provenance

Grok reviewed the transcribed concept and physical scope. Claude reviewed the statistical proposal and reported results. Neither executed this package or verified its full source. Codex executed the local Python harness. External review is advisory, not independent replication or certification.

Grok initially objected to the illustrative fluence/energy assumptions; after challenge it accepted that an effective cross-section may be spectrum-averaged and that the stated fluence is not inherently impossible. The unresolved issue is a concrete source spectrum and background budget.

Claude identified estimated and non-Poisson backgrounds as the principal weakness and recommended on/off inference and fixed trial accounting. In the second review it accepted that Bonferroni does not require independent trials, highlighted conservatism and the single-point power limitation, and supported stopping at an assumption-bounded reference with explicit negative results. Holm was mentioned as a possible later comparison; it is not implemented and would not repair invalid marginal p-values.

## Reproduce

Tested with NumPy 2.3.5 and SciPy 1.17.0. From this directory:

    python3 -m unittest -v test_protocol.py
    python3 experiment.py

The second command regenerates results.json. This is count-level simulation, not particle/light transport, spatial reconstruction, source inference or a quantum experiment.

## Prior art and physical context

- SK-Gd and EGADS: https://www-sk.icrr.u-tokyo.ac.jp/en/sk/about/detector/sk-gd/
- IceCube detector context: https://icecube.wisc.edu/about-us/faq/
- SNEWS 2.0 alert work: https://doi.org/10.1088/1748-0221/19/10/P10017
- AMON HAWC/IceCube coincidence search: https://arxiv.org/abs/2008.10616

These sources establish relevant existing approaches, not validation of Ghostglass.
